from setuptools import setup

setup(
    name='foo-parameterization',
    version='0.1',
    py_modules=['foo_parameterization'],
    install_requires=[],  # Add any dependencies here
    python_requires='>=3.6',
    author='Your Name',
    description='A package for Foo et al. parameterization',
    url='https://github.com/yourusername/foo-parameterization',
    license='MIT',
)
